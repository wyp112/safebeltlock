/**
 * \file
 *
 * \brief User board definition template
 *
 */

/* This file is intended to contain definitions and configuration details for
* features and devices that are available on the board, e.g., frequency and
* startup time for an external crystal, external memory devices, LED and USART
* pins.
*/
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#ifndef USER_BOARD_H
#define USER_BOARD_H

#include <conf_board.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \ingroup group_common_boards
 * \defgroup user_board_group User board
 *
 * @{
 */

void system_board_init(void);

/** Name string macro */
#define BOARD_NAME                "USER_BOARD"

/** @} */
/** \name LED0 definitions
 *  @{ */
#define LED0_PIN                  PIN_PA19//PIN_PA00
#define LED0_ACTIVE               false
#define LED0_INACTIVE             !LED0_ACTIVE
/** @} */


/** @} */
/** \name LED1 definitions
 *  @{ */
#define LED1_PIN                  PIN_PA15//PIN_PA00
#define LED1_ACTIVE               true
#define LED1_INACTIVE             !LED1_ACTIVE
/** @} */


/** @} */
/** \name LED2 definitions
 *  @{ */
#define LED2_PIN                  PIN_PA16//PIN_PA00
#define LED2_ACTIVE               true
#define LED2_INACTIVE             !LED2_ACTIVE
/** @} */

/** @} */
/** \name LED0 definitions
 *  @{ */
#define ACTUATOR_PIN              PIN_PA00
#define ACTUATOR_ACTIVE           false
#define ACTUATOR_INACTIVE         !ACTUATOR_ACTIVE
/** @} */




/** @} */
/** \name HAL definitions
 *  @{ */
#define hall_sig1                 PIN_PA08
/** @} */









/** \name SW0 definitions
 *  @{ */
#define SW0_PIN                   PIN_PB06//PIN_PB03
#define SW0_ACTIVE                false
#define SW0_INACTIVE              !SW0_ACTIVE
#define SW0_EIC_PIN               PIN_PB03A_EIC_EXTINT3
#define SW0_EIC_MUX               MUX_PB03A_EIC_EXTINT3
#define SW0_EIC_PINMUX            PINMUX_PB03A_EIC_EXTINT3
#define SW0_EIC_LINE              3
/** @} */





#ifdef __cplusplus
}
#endif

#endif // USER_BOARD_H
