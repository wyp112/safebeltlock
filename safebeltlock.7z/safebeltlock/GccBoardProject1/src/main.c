/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * Bare minimum empty user application template
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# Minimal main function that starts with a call to system_init()
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */
#include <asf.h>



#define LED1_ON() port_pin_set_output_level(LED1_PIN, LED1_ACTIVE);
#define LED1_OFF() port_pin_set_output_level(LED1_PIN, LED1_INACTIVE);

#define LED2_ON() port_pin_set_output_level(LED2_PIN, LED2_ACTIVE);
#define LED2_OFF() port_pin_set_output_level(LED2_PIN, LED2_INACTIVE);

#define ACTUATOR_ON() port_pin_set_output_level(ACTUATOR_PIN, ACTUATOR_INACTIVE);
#define ACTUATOR_OFF() port_pin_set_output_level(ACTUATOR_PIN, ACTUATOR_ACTIVE);



/*hall signals and magnetic ring speed calculate parameter*/
//const float speed_require=1000;
#define speed_require 1000
float magnetic_ring_speed;
volatile int16_t hall_num;
volatile uint8_t time5ms_n;

volatile bool time5ms_base;

volatile bool speed_state=false;
volatile bool gyro_state=false;


/*gyro parameter*/
volatile uint8_t Re_buf[11],counter=0;
volatile bool sign;


/*LED show time */
volatile uint16_t speed_time1s_count;
uint8_t speed_time5s_count;
volatile uint16_t gyro_time1s_count;
uint8_t gyro_time5s_count;


/*Timer Counter initialization*/
#define CONF_TC_MODULE TC3

void configure_tc(void);
void configure_tc_callbacks(void);
void tc_callback_to_speed_calculate(
    struct tc_module *const module_inst);

struct tc_module tc_instance;

void tc_callback_to_speed_calculate(
    struct tc_module *const module_inst)
{
    //port_pin_toggle_output_level(LED0_PIN);
    //port_pin_toggle_output_level(LED1_PIN);
    //port_pin_toggle_output_level(LED2_PIN);

    time5ms_base=true;

    time5ms_n++;
    magnetic_ring_speed=hall_num*60/(time5ms_n*0.005*18); //speed is cylinder number per minute


    if(time5ms_n>200)
    {
        hall_num=0;
        time5ms_n=0;
    }


    if(speed_require>=0)
    {
        if(magnetic_ring_speed >= speed_require)
        {
            speed_state=true;
            speed_time1s_count=1;
        }
        else
        {

        }

    }
    else
    {
        if(magnetic_ring_speed <= speed_require)
        {
            speed_state=true;
            speed_time1s_count=1;
        }
        else
        {

        }
    }

}

void configure_tc(void)
{

    struct tc_config config_tc;

    tc_get_config_defaults(&config_tc);

    config_tc.counter_size = TC_CTRLA_MODE_COUNT8;

    config_tc.clock_source = GCLK_GENERATOR_0;

    config_tc.clock_prescaler = TC_CLOCK_PRESCALER_DIV256;

    config_tc.counter_8_bit.period = 156;

    tc_init(&tc_instance, CONF_TC_MODULE, &config_tc);

    tc_enable(&tc_instance);

}

void configure_tc_callbacks(void)
{
    tc_register_callback(&tc_instance, tc_callback_to_speed_calculate,
                         TC_CALLBACK_OVERFLOW);

    tc_enable_callback(&tc_instance, TC_CALLBACK_OVERFLOW);

}




/*EXTINT initialization*/
void configure_extint_channel(void);
void configure_extint_callbacks(void);
void extint_detection_callback(void);


void configure_extint_channel(void)
{

    struct extint_chan_conf config_extint_chan;

    extint_chan_get_config_defaults(&config_extint_chan);

    //config_extint_chan.gpio_pin           = PIN_PB06A_EIC_EXTINT6;
    //config_extint_chan.gpio_pin_mux       = MUX_PB06A_EIC_EXTINT6;
    //config_extint_chan.gpio_pin_pull      = EXTINT_PULL_UP;
    //config_extint_chan.detection_criteria = EXTINT_DETECT_RISING;

    config_extint_chan.gpio_pin           = PIN_PA07A_EIC_EXTINT7;
    config_extint_chan.gpio_pin_mux       = MUX_PA07A_EIC_EXTINT7;
    config_extint_chan.gpio_pin_pull      = EXTINT_PULL_UP;
    config_extint_chan.detection_criteria = EXTINT_DETECT_RISING;


    config_extint_chan.filter_input_signal =false;

    extint_chan_set_config(7, &config_extint_chan);

}

void configure_extint_callbacks(void)
{
    extint_register_callback(extint_detection_callback,
                             7,
                             EXTINT_CALLBACK_TYPE_DETECT);

    extint_chan_enable_callback(7,
                                EXTINT_CALLBACK_TYPE_DETECT);

}


void extint_detection_callback(void)
{
    //bool pin_state = port_pin_get_input_level(PIN_PB06);
    //port_pin_toggle_output_level(LED0_PIN);
    //port_pin_toggle_output_level(LED1_PIN);
    //port_pin_toggle_output_level(LED2_PIN);

    bool pin_state = port_pin_get_input_level(hall_sig1);
    if (pin_state==true)
    {
        hall_num++;
    }
    else
    {
        hall_num--;
    }
}


/*USART initialization*/
void usart_read_callback(struct usart_module *const usart_module);
void usart_write_callback(struct usart_module *const usart_module);

void configure_usart(void);
void configure_usart_callbacks(void);

struct usart_module usart_instance;


#define MAX_RX_BUFFER_LENGTH   1

volatile uint8_t rx_buffer[MAX_RX_BUFFER_LENGTH];


void usart_read_callback(struct usart_module *const usart_module)
{


    usart_read_buffer_job(&usart_instance,
                          (uint8_t *)rx_buffer, MAX_RX_BUFFER_LENGTH);

    Re_buf[counter]=rx_buffer[0];
    if(counter==0&&Re_buf[0]!=0x55) return; //�� 0 �����ݲ���֡ͷ������
    counter++;
    if(counter==11) //���յ� 11 ������
    {
        counter=0; //���¸�ֵ��׼����һ֡���ݵĽ���
        sign=1;
    }



}

void usart_write_callback(struct usart_module *const usart_module)
{


}


void configure_usart(void)
{
    struct usart_config config_usart;

    usart_get_config_defaults(&config_usart);

    config_usart.baudrate    = 115200;
    config_usart.mux_setting = USART_RX_2_TX_0_XCK_1;
    config_usart.pinmux_pad0 = PINMUX_PA04D_SERCOM0_PAD0;
    config_usart.pinmux_pad1 = PINMUX_UNUSED;
    config_usart.pinmux_pad2 = PINMUX_PA06D_SERCOM0_PAD2;
    config_usart.pinmux_pad3 = PINMUX_UNUSED;


    while (usart_init(&usart_instance,
                      SERCOM0, &config_usart) != STATUS_OK)
    {
    }

    usart_enable(&usart_instance);
}

void configure_usart_callbacks(void)
{
    usart_register_callback(&usart_instance,
                            usart_write_callback, USART_CALLBACK_BUFFER_TRANSMITTED);
    usart_register_callback(&usart_instance,
                            usart_read_callback, USART_CALLBACK_BUFFER_RECEIVED);


    usart_enable_callback(&usart_instance, USART_CALLBACK_BUFFER_TRANSMITTED);
    usart_enable_callback(&usart_instance, USART_CALLBACK_BUFFER_RECEIVED);
}


float gyro_acceleration[3],gyro_position[3],gyro_angle[3],gyro_temperature;

//const float acc_require=0.35;
//const float pos_require=100;
//const float angle_require=20;
#define acc_require             0.35
#define pos_require             100
#define angle_require           164
#define angle_require_negative  -164
uint8_t temp=0;
void gyro_state_adjument(void)
{
    uint8_t i=0;

    if(sign)
    {
        sign=0;
        temp=0;
        for (i=0; i<10; i++)
        {
            temp+=Re_buf[i];
        }
        if((Re_buf[0]==0x55)&&(Re_buf[10]==temp)) //���֡ͷ
        {
            switch(Re_buf[1])
            {
            case 0x51:
                gyro_acceleration[0] = ((short)(Re_buf[3]<<8| Re_buf[2]))/32768.0*16;
                gyro_acceleration[1] = ((short)(Re_buf[5]<<8| Re_buf[4]))/32768.0*16;
                gyro_acceleration[2] = ((short)(Re_buf[7]<<8| Re_buf[6]))/32768.0*16;
                gyro_temperature = ((short)(Re_buf[9]<<8| Re_buf[8]))/340.0+36.25;
                break;
            case 0x52:
                gyro_position[0] = ((short)(Re_buf[3]<<8| Re_buf[2]))/32768.0*2000;
                gyro_position[1] = ((short)(Re_buf[5]<<8| Re_buf[4]))/32768.0*2000;
                gyro_position[2] = ((short)(Re_buf[7]<<8| Re_buf[6]))/32768.0*2000;
                gyro_temperature = ((short)(Re_buf[9]<<8| Re_buf[8]))/340.0+36.25;
                break;
            case 0x53:
                gyro_angle[0] = ((short)(Re_buf[3]<<8| Re_buf[2]))/32768.0*180;
                gyro_angle[1] = ((short)(Re_buf[5]<<8| Re_buf[4]))/32768.0*180;
                gyro_angle[2] = ((short)(Re_buf[7]<<8| Re_buf[6]))/32768.0*180;
                gyro_temperature = ((short)(Re_buf[9]<<8| Re_buf[8]))/340.0+36.25;
                break;
            default:
                break;
            }
        }

        //if(gyro_angle[0]>angle_require)
        if((gyro_angle[0]>angle_require)||(gyro_angle[0]<angle_require_negative))
        {
            gyro_state=true;
            LED1_ON();
        }
        else
        {
            gyro_state=false;
            LED1_OFF();
        }

        //if((gyro_acceleration[0]>acc_require)||(gyro_acceleration[1]>acc_require)||(gyro_acceleration[2]>acc_require))
        //{
        //gyro_state=true;
        //}
        //else if((gyro_position[0]>pos_require)||(gyro_position[1]>pos_require)||(gyro_position[2]>pos_require))
        //{
        //gyro_state=true;
        //}
        //else if((gyro_angle[0]>angle_require)||(gyro_angle[1]>angle_require)||(gyro_angle[2]>angle_require))
        //{
        //gyro_state=true;
        //}
        //else
        //{
        //gyro_state=false;
        //}
    }
}

int main(void)
{

    system_init();

    configure_tc();
    configure_tc_callbacks();

    configure_extint_channel();
    configure_extint_callbacks();

    configure_usart();
    configure_usart_callbacks();

    system_interrupt_enable_global();

    usart_read_buffer_job(&usart_instance,
                          (uint8_t *)rx_buffer, MAX_RX_BUFFER_LENGTH);

    while (true)
    {

        gyro_state_adjument();


        if(time5ms_base==true)
        {
            time5ms_base=false;

            if (speed_time1s_count>0)
            {
                speed_time5s_count++;
                if(speed_time5s_count>200)
                {
                    speed_time5s_count=0;
                    speed_time1s_count=0;
                }
                LED2_ON();
                if(gyro_state==true)
                {
                    ACTUATOR_ON();
                }
            }
            else
            {
                speed_state=false;
                LED2_OFF();
                ACTUATOR_OFF();
            }

        }
    }
}






